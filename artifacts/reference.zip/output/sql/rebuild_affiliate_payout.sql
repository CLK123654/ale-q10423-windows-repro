PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS commission_ledger;
DROP TABLE IF EXISTS excluded_touchpoints;
DROP TABLE IF EXISTS partner_summary;

CREATE TABLE excluded_touchpoints (
  order_id TEXT NOT NULL,
  click_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  partner_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  detail TEXT NOT NULL,
  PRIMARY KEY (order_id, click_id)
);

WITH click_pairs AS (
  SELECT
    o.order_id,
    o.status AS order_status,
    o.order_ts,
    c.click_id,
    c.user_id,
    c.partner_id,
    c.click_ts,
    c.landing_domain,
    c.self_referral,
    c.fraud_score,
    pa.active AS partner_active,
    (julianday(o.order_ts) - julianday(c.click_ts)) * 24.0 AS hours_before_order
  FROM orders AS o
  JOIN click_touchpoints AS c
    ON c.user_id = o.user_id
   AND c.click_ts <= o.order_ts
  JOIN partner_accounts AS pa ON pa.partner_id = c.partner_id
),
base_exclusions AS (
  SELECT
    order_id,
    click_id,
    user_id,
    partner_id,
    CASE
      WHEN order_status <> {{PAYABLE_STATUS}} THEN 'order_not_payable'
      WHEN landing_domain <> {{REQUIRED_DOMAIN}} THEN 'wrong_landing_domain'
      WHEN hours_before_order > {{ATTRIBUTION_WINDOW_HOURS}} THEN 'outside_window'
      WHEN self_referral = 1 THEN 'self_referral'
      WHEN fraud_score >= {{FRAUD_CUTOFF}} THEN 'fraud_score_block'
      WHEN partner_active = 0 THEN 'partner_inactive'
    END AS reason,
    printf(
      'hours_before_order=%.1f; fraud_score=%d; partner_active=%d',
      hours_before_order,
      fraud_score,
      partner_active
    ) AS detail
  FROM click_pairs
),
qualified AS (
  SELECT
    click_pairs.*,
    ROW_NUMBER() OVER (
      PARTITION BY order_id
      ORDER BY click_ts DESC, click_id DESC
    ) AS qualified_rank
  FROM click_pairs
  WHERE order_status = {{PAYABLE_STATUS}}
    AND landing_domain = {{REQUIRED_DOMAIN}}
    AND hours_before_order <= {{ATTRIBUTION_WINDOW_HOURS}}
    AND self_referral = 0
    AND fraud_score < {{FRAUD_CUTOFF}}
    AND partner_active = 1
)
INSERT INTO excluded_touchpoints (
  order_id, click_id, user_id, partner_id, reason, detail
)
SELECT order_id, click_id, user_id, partner_id, reason, detail
FROM base_exclusions
WHERE reason IS NOT NULL
UNION ALL
SELECT
  order_id,
  click_id,
  user_id,
  partner_id,
  'superseded_by_later_click',
  'another qualified click is later for the same order'
FROM qualified
WHERE qualified_rank > 1;

CREATE TABLE commission_ledger (
  order_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  net_amount_cents INTEGER NOT NULL,
  attributed_click_id TEXT,
  partner_id TEXT,
  commission_rate_bps INTEGER NOT NULL,
  commission_cents INTEGER NOT NULL,
  attribution_reason TEXT NOT NULL
);

WITH order_net AS (
  SELECT
    o.order_id,
    o.user_id,
    o.order_ts,
    o.order_amount_cents - COALESCE(SUM(r.refund_amount_cents), 0) AS net_amount_cents
  FROM orders AS o
  LEFT JOIN refunds AS r ON r.order_id = o.order_id
  WHERE o.status = {{PAYABLE_STATUS}}
  GROUP BY o.order_id, o.user_id, o.order_ts, o.order_amount_cents
),
qualified AS (
  SELECT
    order_net.order_id,
    c.click_id,
    c.partner_id,
    CASE pa.tier
      WHEN 'standard' THEN {{STANDARD_BPS}}
      WHEN 'preferred' THEN {{PREFERRED_BPS}}
      WHEN 'premium' THEN {{PREMIUM_BPS}}
      ELSE 0
    END AS commission_rate_bps,
    ROW_NUMBER() OVER (
      PARTITION BY order_net.order_id
      ORDER BY c.click_ts DESC, c.click_id DESC
    ) AS qualified_rank
  FROM order_net
  JOIN click_touchpoints AS c
    ON c.user_id = order_net.user_id
   AND c.click_ts <= order_net.order_ts
  JOIN partner_accounts AS pa ON pa.partner_id = c.partner_id
  WHERE c.landing_domain = {{REQUIRED_DOMAIN}}
    AND (julianday(order_net.order_ts) - julianday(c.click_ts)) * 24.0 <= {{ATTRIBUTION_WINDOW_HOURS}}
    AND c.self_referral = 0
    AND c.fraud_score < {{FRAUD_CUTOFF}}
    AND pa.active = 1
)
INSERT INTO commission_ledger (
  order_id,
  user_id,
  net_amount_cents,
  attributed_click_id,
  partner_id,
  commission_rate_bps,
  commission_cents,
  attribution_reason
)
SELECT
  order_net.order_id,
  order_net.user_id,
  order_net.net_amount_cents,
  qualified.click_id,
  qualified.partner_id,
  COALESCE(qualified.commission_rate_bps, 0),
  CAST(order_net.net_amount_cents * COALESCE(qualified.commission_rate_bps, 0) / 10000 AS INTEGER),
  CASE
    WHEN qualified.click_id IS NULL THEN 'no_qualified_click'
    ELSE 'attributed_last_qualified'
  END
FROM order_net
LEFT JOIN qualified
  ON qualified.order_id = order_net.order_id
 AND qualified.qualified_rank = 1;

CREATE TABLE partner_summary (
  partner_id TEXT PRIMARY KEY,
  payable_order_count INTEGER NOT NULL,
  net_amount_cents INTEGER NOT NULL,
  commission_cents INTEGER NOT NULL,
  order_ids TEXT NOT NULL
);

INSERT INTO partner_summary (
  partner_id,
  payable_order_count,
  net_amount_cents,
  commission_cents,
  order_ids
)
SELECT
  COALESCE(partner_id, 'UNATTRIBUTED'),
  COUNT(*),
  SUM(net_amount_cents),
  SUM(commission_cents),
  GROUP_CONCAT(order_id, '|')
FROM (
  SELECT * FROM commission_ledger ORDER BY order_id
)
GROUP BY COALESCE(partner_id, 'UNATTRIBUTED');
