# 联盟佣金结算材料

database/affiliate_payout.db来自本次联盟佣金结算批次，包含订单、点击触点、合作方账户和退款记录，用户与合作方字段已脱敏。rules/commission_rules.json给出本轮归因窗口、可付款状态、落地域名、反作弊阈值、佣金档位、舍入口径和裁决顺序。starter/rebuild_affiliate_payout.sql是待完成的SQLite脚本，tools/run_task.py读取上述材料并导出交付物。

数据库提供结算事实，规则文件决定筛选与计算口径，SQL承载SQLite归因和汇总逻辑。把完成SQL保存到output/sql/rebuild_affiliate_payout.sql，在input_data目录运行py tools/run_task.py。
