-- 修复此文件。保留 {{...}} 规则占位符，运行器会从 commission_rules.json 渲染实际值。
-- TODO：重建 commission_ledger、excluded_touchpoints 和 partner_summary。
PRAGMA foreign_keys = ON;

SELECT 1;
