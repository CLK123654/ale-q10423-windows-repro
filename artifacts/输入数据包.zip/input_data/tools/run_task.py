from __future__ import annotations

import csv
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
from contextlib import closing
from pathlib import Path


INPUT_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = INPUT_ROOT.parent
OUTPUT_ROOT = PACKAGE_ROOT / "output"
STAGE_ROOT = PACKAGE_ROOT / ".affiliate_payout_stage"
DATABASE_PATH = INPUT_ROOT / "database" / "affiliate_payout.db"
RULES_PATH = INPUT_ROOT / "rules" / "commission_rules.json"
SQL_TEMPLATE_PATH = INPUT_ROOT / "starter" / "rebuild_affiliate_payout.sql"
SOURCE_TABLES = ("orders", "click_touchpoints", "partner_accounts", "refunds")
DERIVED_TABLES = ("commission_ledger", "excluded_touchpoints", "partner_summary")


def fail(message: str) -> None:
    raise RuntimeError(message)


def table_rows(connection: sqlite3.Connection, table: str) -> list[tuple]:
    columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
    if not columns:
        fail(f"缺少数据表：{table}")
    primary = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")') if row[5]]
    order = primary or columns
    return connection.execute(
        f'SELECT * FROM "{table}" ORDER BY ' + ",".join(f'"{column}"' for column in order)
    ).fetchall()


def source_snapshot(connection: sqlite3.Connection) -> dict[str, list[tuple]]:
    return {table: table_rows(connection, table) for table in SOURCE_TABLES}


def read_rules() -> dict:
    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))
    required = {
        "attribution_window_hours",
        "payable_order_status",
        "landing_domain",
        "fraud_score_block_at_or_above",
        "commission_rate_bps_by_tier",
        "commission_rounding",
        "tie_breaker",
        "exclusion_precedence",
    }
    if set(rules) != required:
        fail("commission_rules.json字段与结算规则不一致")
    if not isinstance(rules["attribution_window_hours"], int) or rules["attribution_window_hours"] <= 0:
        fail("attribution_window_hours必须是正整数")
    if not isinstance(rules["fraud_score_block_at_or_above"], int):
        fail("反作弊阈值必须是整数")
    if rules["commission_rounding"] != "floor_to_cent":
        fail("不支持当前佣金舍入口径")
    if rules["tie_breaker"] != ["click_ts_desc", "click_id_desc"]:
        fail("不支持当前触点排序规则")
    expected_precedence = [
        "order_not_payable",
        "wrong_landing_domain",
        "outside_window",
        "self_referral",
        "fraud_score_block",
        "partner_inactive",
    ]
    if rules["exclusion_precedence"] != expected_precedence:
        fail("不支持当前触点排除顺序")
    rates = rules["commission_rate_bps_by_tier"]
    if set(rates) != {"standard", "preferred", "premium"} or not all(
        isinstance(value, int) and 0 <= value <= 10000 for value in rates.values()
    ):
        fail("三个合作方档位的佣金率必须使用整数基点")
    return rules


def sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def render_sql(template: str, rules: dict) -> str:
    if "TODO" in template.upper():
        fail("归因SQL尚未完成")
    rates = rules["commission_rate_bps_by_tier"]
    replacements = {
        "{{ATTRIBUTION_WINDOW_HOURS}}": str(rules["attribution_window_hours"]),
        "{{PAYABLE_STATUS}}": sql_string(rules["payable_order_status"]),
        "{{REQUIRED_DOMAIN}}": sql_string(rules["landing_domain"]),
        "{{FRAUD_CUTOFF}}": str(rules["fraud_score_block_at_or_above"]),
        "{{STANDARD_BPS}}": str(rates["standard"]),
        "{{PREFERRED_BPS}}": str(rates["preferred"]),
        "{{PREMIUM_BPS}}": str(rates["premium"]),
    }
    rendered = template
    for token, value in replacements.items():
        if token not in rendered:
            fail(f"归因SQL缺少规则占位符{token}")
        rendered = rendered.replace(token, value)
    leftovers = re.findall(r"\{\{[^{}]+\}\}", rendered)
    if leftovers:
        fail("归因SQL包含未知占位符：" + ", ".join(sorted(set(leftovers))))
    return rendered


def sqlite_executable() -> str:
    configured = os.environ.get("SQLITE3_PATH")
    executable = configured or shutil.which("sqlite3")
    if not executable:
        fail("找不到SQLite命令行程序，请安装SQLite并设置SQLITE3_PATH")
    version = subprocess.run(
        [executable, "--version"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if version.returncode != 0:
        fail("无法读取SQLite版本")
    match = re.match(r"(\d+)\.(\d+)\.(\d+)", version.stdout.strip())
    if not match or tuple(map(int, match.groups())) < (3, 40, 0):
        fail(f"需要SQLite3.40或更高版本，当前版本为{version.stdout.strip()}")
    return executable


def execute_sqlite(executable: str, database: Path, sql: str) -> None:
    result = subprocess.run(
        [executable, "-batch", "-bail", str(database)],
        input=sql,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        fail(f"SQLite执行失败：{detail}")


def write_csv(connection: sqlite3.Connection, table: str, target: Path, order_by: str) -> list[tuple]:
    cursor = connection.execute(f'SELECT * FROM "{table}" ORDER BY {order_by}')
    rows = cursor.fetchall()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow([column[0] for column in cursor.description])
        writer.writerows(rows)
    return rows


def main() -> None:
    if OUTPUT_ROOT.exists():
        shutil.rmtree(OUTPUT_ROOT)
    if STAGE_ROOT.exists():
        shutil.rmtree(STAGE_ROOT)
    try:
        for required in (DATABASE_PATH, RULES_PATH, SQL_TEMPLATE_PATH):
            if not required.is_file():
                fail(f"缺少输入文件：{required.relative_to(PACKAGE_ROOT)}")
        executable = sqlite_executable()
        rules = read_rules()
        template = SQL_TEMPLATE_PATH.read_text(encoding="utf-8")
        rendered_sql = render_sql(template, rules)

        STAGE_ROOT.mkdir(parents=True)
        reports = STAGE_ROOT / "reports"
        sql_dir = STAGE_ROOT / "sql"
        reports.mkdir()
        sql_dir.mkdir()
        repaired_db = STAGE_ROOT / "affiliate_payout_repaired.db"
        shutil.copy2(DATABASE_PATH, repaired_db)

        with closing(sqlite3.connect(repaired_db)) as connection:
            connection.execute("PRAGMA foreign_keys = ON")
            before = source_snapshot(connection)

        execute_sqlite(executable, repaired_db, rendered_sql)

        with closing(sqlite3.connect(repaired_db)) as connection:
            connection.execute("PRAGMA foreign_keys = ON")
            if source_snapshot(connection) != before:
                fail("业务源表被改写")
            if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                fail("SQLite完整性检查失败")
            foreign_key_violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if foreign_key_violations:
                fail("SQLite外键检查发现异常")

            write_csv(connection, "commission_ledger", reports / "commission_ledger.csv", "order_id")
            write_csv(connection, "excluded_touchpoints", reports / "excluded_touchpoints.csv", "order_id, click_id")
            write_csv(connection, "partner_summary", reports / "partner_summary.csv", "partner_id")
        (sql_dir / "rebuild_affiliate_payout.sql").write_text(template, encoding="utf-8")
        shutil.move(str(STAGE_ROOT), str(OUTPUT_ROOT))
        print(json.dumps({"result": "PASS", "output": str(OUTPUT_ROOT)}, ensure_ascii=False))
    except Exception:
        if STAGE_ROOT.exists():
            shutil.rmtree(STAGE_ROOT)
        if OUTPUT_ROOT.exists():
            shutil.rmtree(OUTPUT_ROOT)
        raise


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
